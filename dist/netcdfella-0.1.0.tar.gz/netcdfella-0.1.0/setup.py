# -*- coding: utf-8 -*-
from setuptools import setup

package_dir = \
{'': 'src'}

packages = \
['netcdfella']

package_data = \
{'': ['*']}

entry_points = \
{'console_scripts': ['netcdfella = cli.__main__:main']}

setup_kwargs = {
    'name': 'netcdfella',
    'version': '0.1.0',
    'description': 'Netcdfella is providing multiple ways to convert netcdf filed into other data types such as ASCII, PNG and JPG, and even create graphs.',
    'long_description': '',
    'author': 'Nikos Fotiou',
    'author_email': 'nik_fot@hotmail.gr',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'https://nikfot.github.io/netcdfella/',
    'package_dir': package_dir,
    'packages': packages,
    'package_data': package_data,
    'entry_points': entry_points,
    'python_requires': '>=3.10.4,<4.0.0',
}


setup(**setup_kwargs)
